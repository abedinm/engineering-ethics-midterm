# Speaking Script - just read this out

**EEE 2215 Engineering Ethics - CO2 Mid-Term Presentation**  
Minhazul Abedin | ID 21-44625-1 | Section I

Total: **6:26** of speaking at a normal reading pace.

---

## How to use it

This exact text is also inside the PowerPoint file as speaker notes. While you record, press
**Alt+F5** for Presenter View and it appears on your screen. The camera and the audience only
see the slide, never your notes. So you can simply read.

Read at a calm, normal speed. Pause at every blank line. Do not rush.

## Say these words like this

| Word | Say it as |
|---|---|
| LeMessurier | luh-MESS-uh-ree-ay |
| Citicorp | SIT-ee-corp |
| paramount | PARA-mount |
| quartering wind | KWOR-ter-ing wind |
| NSPE | say the letters: N - S - P - E |
| IEEE | say: I - triple - E |
| ACM / IEB | say the letters |

## If you are running out of time

Cut the last paragraph of **slide 2** (the one starting *"Why do codes exist at all"*) and the
hurricane sentence on **slide 8**. Never cut slides 6 and 7 - those carry the most marks.

---

## Slide 1 - Title slide

*0:28*

Good morning. My name is Minhazul Abedin. My ID is 21-44625-1, Section I.

This is my mid term presentation for Engineering Ethics.

I am presenting alone, with my faculty's permission. He also allowed me to choose my own principle.

The principle I chose is this. Hold paramount the safety, health and welfare of the public.

First I will explain it. Then I will test it on a real case.

*(click to the next slide)*

---

## Slide 2 - One Clause, Four Professional Codes

*0:52*

Four bodies write codes of ethics for engineers. N S P E, I triple E, A C M, and I E B.

All four put the same sentence first. Hold paramount the safety, health and welfare of the public.

Now please look at the word paramount.

It does not mean important. It does not mean balanced.

It means this comes above everything else. Above cost. Above time. Above the client. Above the engineer's own career.

So this principle does not join the argument. It ends the argument.

Why do codes exist at all? Because engineers know things the public cannot check. The public has to trust us. The code is that promise, written down.

All four codes also say the engineer must speak up. So staying silent is never safe.

*(click to the next slide)*

---

## Slide 3 - Citicorp Center, New York - 1977

*0:37*

Now the real case. This is Citicorp Center in New York, finished in 1977. Fifty nine floors, in the middle of Manhattan.

The engineer of record was William LeMessurier.

There was a problem with the land. A church owned one corner, and refused to sell. So the tower could not have columns at its corners.

Instead, the engineer put four big columns at the middle of each side. You can see this in the picture. The corners hang in the air.

When it was designed, the building was safe. People praised it.

*(click to the next slide)*

---

## Slide 4 - The Flaw: What Nobody Had Checked

*1:04*

Then in July 1978, a student asked him a question about wind. So he checked his calculations again.

Please look at the top picture.

The building code only asked him to check wind hitting the flat faces. That is the green side. It passed.

But nobody checked wind hitting the corners. That is the red side. This is called a quartering wind. And on this building, the corners carry nothing.

The load on the joints went up by 160 percent.

Now please look at the bottom left picture. These joints should have been welded. During construction they were bolted instead, to save money. His own office approved that change.

Now the red bar on the right. The damper is a heavy weight on the roof that stops the building swaying. Without it, this building had a one in sixteen chance of falling down. Not in its lifetime. In any single year.

And the building was already full of people.

*(click to the next slide)*

---

## Slide 5 - The Moral Issue, Facts and Stakeholders

*0:41*

So here is the moral problem.

Should an engineer stay silent about a deadly mistake in his own building?

If he speaks, he loses his career. And the mistake came from his own office. So to tell the truth, he must admit his own fault.

On the left you can see the values in conflict. On the right you can see the people affected.

Please look at the first line on the right. The people inside the building had their lives at risk. They did not know. And nobody asked them.

Everyone else could lose money. Only they could lose their life.

*(click to the next slide)*

---

## Slide 6 - The Decision Space, Tested Against the Codes

*0:46*

He had four possible choices. I tested each one against the codes.

Option A. Say nothing. This puts his reputation above human life. It breaks both rules. So it is unacceptable.

Option B. Wait until the storm season is over. This looks safer, but it is not. It keeps people in danger for months. And promptly cannot mean next year. So this is also unacceptable.

Option C. Tell everyone now, and repair now. This follows both rules.

Option D. Announce it to the public at once. This also follows the rules, but it could cause panic in the city.

So A and B are removed immediately. The real choice is between C and D.

*(click to the next slide)*

---

## Slide 7 - The Decision and Why It Is Justified

*0:40*

My decision is option C.

He should tell the client, the architect and the city. And he should repair the building immediately.

I have three reasons.

First, please look at the diagram. Public safety sits on top. Cost, time, the client, and his career all sit below it. The code tells him which one wins.

Second, the public never agreed to this risk, because they never knew about it.

Third, it does not matter whose mistake it was. He is the engineer of record, so he is responsible.

And option C is exactly what he did in real life.

*(click to the next slide)*

---

## Slide 8 - What He Did, and the Question Left Open

*0:42*

Please look at the timeline.

He told his insurance company, then the architect, then Citicorp, and then the Mayor of New York.

For two months, workers welded steel plates over two hundred joints. They worked at night, so people could still use the building in the day.

A hurricane came halfway through the repair. Luckily it turned away.

But now please look at the red line. The public was never told. Not for seventeen years.

So the principle told him what to do. But it did not tell him who deserved to know the truth. And none of the four codes answers that question.

*(click to the next slide)*

---

## Slide 9 - Conclusion

*0:36*

To conclude, I have four points.

One. All four codes put this same sentence first. Different countries, same rule.

Two. Paramount is a ranking. It does not join the argument, it ends it.

Three. This principle works even when it hurts the engineer. His decision was expensive and risked his career, but it was correct.

Four. It does not answer everything. So a code cannot replace the engineer's own judgement.

A code of ethics is a floor. It is not a ceiling.

Thank you. I am happy to answer any questions.

*(click to the next slide)*

---

## Slide 10 - References

*0:02*

These are my references. Thank you.

*(click to the next slide)*

---
