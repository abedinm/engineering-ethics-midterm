# Speaker Script - 5 Minute Version

**EEE 2215 - Engineering Ethics and Environmental Protection**  
CO2 Mid-Term OBE Presentation | Term: Mid | Semester: Summer 2025-2026 | Total Marks: 40  
Presented by Minhazul Abedin | Course Faculty: Joheb Muhammad Tanzeer Sayeed

**Selected principle:** *Hold paramount the safety, health and welfare of the public.*  
**Case study:** Citicorp Center, New York, 1978 - William J. LeMessurier.

**10 slides | 5:42 spoken at a normal pace (140 wpm).**

---

## How to use this

Every word below is also embedded in the .pptx as speaker notes. Press **Alt+F5** for Presenter View - the audience sees the slide, you see the script.

Do not read it out word for word. Read it through twice, then present from the bold ideas. It is written the way you would say it out loud.

At five minutes there is no slack. Two rules: **do not add anything**, and **do not stop to explain the slide visuals** - let them be read while you talk.

## Pacing

| # | Slide | Target |
|---|---|---|
| 1 | Hold Paramount the Safety, Health and Welfare of the Public | 0:21 |
| 2 | One Clause, Four Professional Codes | 0:39 |
| 3 | Citicorp Center, New York — 1977 | 0:34 |
| 4 | The Flaw: What Nobody Had Checked | 0:45 |
| 5 | The Moral Issue, the Facts and the Stakeholders | 0:40 |
| 6 | The Decision Space, Tested Against the Codes | 0:42 |
| 7 | The Decision — and Why It Is Justified | 0:38 |
| 8 | What He Did — and the Question Left Open | 0:40 |
| 9 | What This Principle Is For | 0:37 |
| 10 | References | 0:06 |
| | **Total** | **5:42** |

If you overrun, the two places to save time are **slide 3** (drop the sentence about the church and the stilts) and **slide 7** (read only the first bullet in each column). Never rush **slides 2, 5 and 6** - the four codes, the evaluation table and the justification carry most of the rubric marks.

## Before you present

- Slide 1 already carries your ID (21-44625-1) and Section (I). Nothing left to fill in.
- Confirm whether the faculty wants `.pptx` or PDF before uploading.
- The diagrams are embedded in the file - it is self-contained, nothing will go missing on his machine.
- *"Is this a real case?"* - Yes. It became public through Joe Morgenstern's "The Fifty-Nine-Story Crisis", The New Yorker, 29 May 1995.
- *"Why this principle?"* - Because it is the only clause that appears first in all four codes on the syllabus, and because *paramount* makes it a ranking rather than a weighting, which is what makes it usable in a real dilemma.
- *"Why did the bolted joints matter?"* - Bolted connections were adequate for winds hitting the faces straight on, which is what the code required checking. They were not adequate for quartering winds, which raised the load at those joints by about 160%.

---

## Slide 1 - Hold Paramount the Safety, Health and Welfare of the Public

*0:21*

Good morning. I am Minhazul Abedin, and this is my individual mid-term presentation for Engineering Ethics.

My selected principle is the one every major engineering code places first: hold paramount the safety, health and welfare of the public. I will define it, then test it against a real case.

---

## Slide 2 - One Clause, Four Professional Codes

*0:39*

Here is why I chose this principle. As the diagram shows, it is the only clause that appears first in all four codes on our syllabus — NSPE, IEEE, ACM and IEB. Four different bodies, four different countries, converging on one sentence.

Note the word paramount. The codes do not say balance public safety, or consider it. Paramount means it outranks everything else — cost, schedule, the client, your own career. That is a ranking, not a weighting.

All four also attach a duty to disclose. So silence is never neutral.

---

## Slide 3 - Citicorp Center, New York — 1977

*0:34*

Now a real case. Citicorp Center, 59 storeys in midtown Manhattan, completed 1977. Engineer of record: William LeMessurier.

Look at the diagram. St. Peter's Church owned one corner and would not sell, so the tower could not have columns at its corners. It stands instead on four stilts at the midpoints of its sides, corners cantilevered. Wind load is carried by the chevron bracing on the face, plus a tuned mass damper at the top.

As designed, it was sound.

---

## Slide 4 - The Flaw: What Nobody Had Checked

*0:45*

In July 1978 a student's question prompted LeMessurier to check something the code did not require.

Top diagram: the code required checking wind hitting the faces — the green case. Nobody checked quartering winds, striking the corners diagonally, and on this building the corners carry nothing. Load at the brace joints rose 160 percent.

Bottom left: those joints had been bolted during construction instead of welded, to save cost — approved through his own office.

The result is the red bar. Without the damper, which dies with the mains power in a storm, a one-in-sixteen chance of collapse in any year. The building was occupied.

---

## Slide 5 - The Moral Issue, the Facts and the Stakeholders

*0:40*

So the moral issue: may an engineer stay silent about a life-threatening defect in his own completed work, when speaking destroys his career and the defect traces back to his own office? That last part is what makes it hard — disclosure means admitting his own mistake.

On the left, the values in conflict. On the right, the stakeholders. Notice the first line: the occupants had their lives at risk, no knowledge of it, and no chance to consent. Every other party stood to lose money. Only they stood to lose their lives.

---

## Slide 6 - The Decision Space, Tested Against the Codes

*0:42*

Four realistic options, each tested against the actual clauses.

Option A, say nothing — violates hold paramount, and violates the disclosure duty. Unacceptable.

Option B, wait until after hurricane season. Delay looks moderate, but it knowingly extends the exposure, and promptly cannot mean next year. Also unacceptable.

Option C, disclose and repair now — satisfies both tests, at real personal cost.

Option D, go fully public — satisfies the letter, but a panicked evacuation could raise total harm.

So A and B are eliminated by Whitbeck's background constraints before any weighing begins. The real choice is C or D.

---

## Slide 7 - The Decision — and Why It Is Justified

*0:38*

The decision is option C. Three reasons, and the diagram on the left is the first one. Paramountcy is a ranking, not a weighting — public safety sits above cost, schedule, the client's interests and the engineer's own career. The clause tells you which side wins.

Second, the public never consented, because they never knew.

Third, whose mistake it was does not change the duty. The instinct to avoid blame for your own error is exactly what paramount exists to override.

And option C is what he actually did.

---

## Slide 8 - What He Did — and the Question Left Open

*0:40*

The timeline shows what happened. He told his insurer, the architect, Citicorp, then the mayor and the buildings commissioner. Through August and September 1978 crews welded steel plates over more than two hundred joints, at night, so the building stayed occupied. Hurricane Ella came up the coast halfway through and turned east.

But look at the red stretch. The public was never told — for seventeen years. Holding safety paramount told him what to do. It did not tell him who was owed the truth, and none of the four codes answers that.

---

## Slide 9 - What This Principle Is For

*0:37*

To conclude. One clause sits at the top of NSPE, IEEE, ACM and IEB — different bodies, different countries, the same first sentence.

Paramount is a ranking, not a weighting; it settles conflicts rather than joining them.

It binds the engineer even when the cost is personal — which is what makes it a principle rather than a slogan.

And it does not resolve everything, which is why a code cannot replace individual judgement.

A code of ethics is a floor, not a ceiling. Thank you.

---

## Slide 10 - References

*0:06*

Do not read this slide aloud. Leave it on screen and take questions.

---
